export interface AssessmentData {
  phLevel: string;
  vocLevel: string;
  image: string | null; // Base64 string
}

export enum AppState {
  GUIDE = 'GUIDE',
  INPUT = 'INPUT',
  CAMERA = 'CAMERA',
  ANALYZING = 'ANALYZING',
  RESULT = 'RESULT',
  ERROR = 'ERROR'
}

export const VOC_OPTIONS = [
  { value: 'Normal', label: 'Normal / Low Odor' },
  { value: 'Moderate', label: 'Moderately Elevated' },
  { value: 'High', label: 'Strong Sulfur / High' }
];
