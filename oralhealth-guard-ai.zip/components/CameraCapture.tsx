import React, { useRef, useState, useEffect } from 'react';
import { Camera, RefreshCw, Image as ImageIcon, XCircle, Upload } from 'lucide-react';

interface CameraCaptureProps {
  onCapture: (base64Image: string) => void;
  onCancel: () => void;
}

export const CameraCapture: React.FC<CameraCaptureProps> = ({ onCapture, onCancel }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    startCamera();
    return () => stopCamera();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user' },
        audio: false
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
      setError('');
    } catch (err) {
      console.error("Camera error:", err);
      setError("Camera access denied or unavailable.");
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  const takePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');

      if (context) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        const imageData = canvas.toDataURL('image/jpeg', 0.8);
        stopCamera();
        onCapture(imageData);
      }
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        stopCamera();
        onCapture(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerFileUpload = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="flex flex-col items-center w-full max-w-md mx-auto animate-fade-in">
      
      <div className="relative w-full aspect-[3/4] bg-slate-800 rounded-3xl overflow-hidden shadow-2xl shadow-sky-900/20 mb-6 border-4 border-slate-700">
        {!error ? (
          <>
             <video 
              ref={videoRef}
              autoPlay 
              playsInline 
              className="w-full h-full object-cover transform scale-x-[-1]" 
            />
            {/* Guide Overlay */}
            <div className="absolute inset-0 border-2 border-sky-400/30 rounded-3xl pointer-events-none flex items-center justify-center">
              <div className="border-2 border-dashed border-white/40 w-48 h-48 rounded-full flex items-center justify-center">
                <p className="text-white font-medium bg-black/40 backdrop-blur-sm px-3 py-1 rounded-full text-xs">Stick out tongue</p>
              </div>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full bg-slate-900 text-rose-400 p-6 text-center">
             <Camera className="w-12 h-12 mb-2 opacity-50" />
             <p className="text-sm font-medium">{error}</p>
             <p className="text-xs mt-2 text-rose-300">Please upload a photo instead.</p>
          </div>
        )}
        <canvas ref={canvasRef} className="hidden" />
      </div>

      <input 
        type="file" 
        ref={fileInputRef} 
        accept="image/*" 
        className="hidden" 
        onChange={handleFileUpload}
      />

      <div className="flex items-center justify-center gap-6 w-full">
        <button 
          onClick={triggerFileUpload}
          className="flex flex-col items-center gap-1 text-slate-400 hover:text-sky-400 transition-colors group"
        >
          <div className="p-4 bg-slate-800 rounded-2xl shadow-sm border border-slate-700 group-hover:border-sky-500/50 group-hover:shadow-sky-900/20 transition-all">
            <ImageIcon className="w-6 h-6" />
          </div>
          <span className="text-xs font-medium">Upload</span>
        </button>

        {!error && (
          <button 
            onClick={takePhoto}
            className="w-20 h-20 bg-sky-500 rounded-full flex items-center justify-center hover:bg-sky-400 transition-all shadow-lg shadow-sky-500/30 active:scale-95 border-4 border-slate-900 ring-4 ring-sky-500/30"
            title="Capture Photo"
          >
            <Camera className="w-8 h-8 text-white" />
          </button>
        )}

        {!error && (
           <button 
           onClick={() => { stopCamera(); startCamera(); }}
           className="flex flex-col items-center gap-1 text-slate-400 hover:text-sky-400 transition-colors group"
         >
           <div className="p-4 bg-slate-800 rounded-2xl shadow-sm border border-slate-700 group-hover:border-sky-500/50 group-hover:shadow-sky-900/20 transition-all">
             <RefreshCw className="w-6 h-6" />
           </div>
           <span className="text-xs font-medium">Flip</span>
         </button>
        )}
      </div>

      <button 
        onClick={onCancel}
        className="mt-8 text-slate-500 text-sm font-medium hover:text-rose-400 transition-colors flex items-center gap-1"
      >
        <XCircle className="w-4 h-4" />
        Cancel Scan
      </button>
    </div>
  );
};
