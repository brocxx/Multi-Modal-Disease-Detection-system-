import React from 'react';
import { AlertCircle, CheckCircle, Info, RefreshCw } from 'lucide-react';

interface ReportViewProps {
  result: string;
  onReset: () => void;
}

export const ReportView: React.FC<ReportViewProps> = ({ result, onReset }) => {
  const getStatusColor = (text: string) => {
    if (text.includes("DANGER")) return "rose";
    if (text.includes("CAUTION")) return "amber";
    if (text.includes("SAFE")) return "emerald";
    return "slate";
  };

  const statusColor = getStatusColor(result);

  const renderStatusBadge = () => {
    switch(statusColor) {
        case 'emerald':
            return <div className="inline-flex items-center gap-2 bg-emerald-900/30 text-emerald-400 border border-emerald-800/50 px-6 py-2.5 rounded-full font-bold text-sm shadow-sm tracking-wide"><CheckCircle size={18} /> SAFE</div>
        case 'amber':
            return <div className="inline-flex items-center gap-2 bg-amber-900/30 text-amber-400 border border-amber-800/50 px-6 py-2.5 rounded-full font-bold text-sm shadow-sm tracking-wide"><AlertCircle size={18} /> CAUTION</div>
        case 'rose':
            return <div className="inline-flex items-center gap-2 bg-rose-900/30 text-rose-400 border border-rose-800/50 px-6 py-2.5 rounded-full font-bold text-sm shadow-sm tracking-wide"><AlertCircle size={18} /> DANGER</div>
        default:
            return <div className="inline-flex items-center gap-2 bg-slate-800 text-slate-300 px-6 py-2.5 rounded-full font-bold text-sm shadow-sm">UNCERTAIN</div>
    }
  }

  const formatText = (text: string) => {
    return text.split('\n').map((line, index) => {
      const trimmed = line.trim();
      if (!trimmed) return <div key={index} className="h-3" />;

      if (trimmed.startsWith('OVERALL HEALTH STATUS:')) {
        return null; 
      }

      if (trimmed.endsWith(':') || (trimmed.toUpperCase() === trimmed && trimmed.length > 5)) {
        return <h3 key={index} className="text-sky-400 font-bold mt-5 mb-3 uppercase text-xs tracking-widest">{trimmed.replace(':', '')}</h3>;
      }

      if (trimmed.startsWith('- ')) {
        return <li key={index} className="ml-4 list-disc text-slate-300 mb-2 pl-2 marker:text-rose-400">{trimmed.substring(2)}</li>;
      }

      return <p key={index} className="text-slate-300 mb-2 leading-relaxed">{trimmed}</p>;
    });
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <div className={`bg-slate-900 rounded-3xl shadow-xl shadow-sky-900/10 overflow-hidden border-t-8 border-${statusColor}-500 ring-1 ring-slate-800`}>
        <div className="p-10 text-center border-b border-slate-800 bg-slate-900">
          <p className="text-slate-500 text-xs font-bold uppercase tracking-widest mb-4">Assessment Result</p>
          {renderStatusBadge()}
        </div>
        
        <div className="p-8 md:p-10 bg-gradient-to-b from-slate-900 to-slate-950">
           <div className="prose prose-invert max-w-none text-sm md:text-base font-medium">
             {formatText(result)}
           </div>
        </div>

        <div className="bg-slate-900/80 p-6 border-t border-slate-800">
          <div className="flex items-start gap-3">
             <Info className="w-5 h-5 text-sky-400 flex-shrink-0 mt-0.5" />
             <p className="text-sky-200/60 text-xs leading-relaxed">
               Disclaimer: This tool is a screening and awareness system, not a medical diagnosis. 
               Always consult a qualified dentist or healthcare professional for confirmation and treatment.
             </p>
          </div>
        </div>
      </div>

      <button
        onClick={onReset}
        className="w-full py-4 bg-transparent border-2 border-slate-700 text-slate-400 rounded-2xl font-bold hover:bg-slate-800 hover:text-slate-200 hover:border-slate-600 transition-all flex items-center justify-center gap-2 shadow-sm"
      >
        <RefreshCw className="w-5 h-5 text-rose-400" />
        Start New Screening
      </button>
    </div>
  );
};
