import React from 'react';
import { ArrowRight, Info, Droplets, Wind, Camera, CheckSquare, ClipboardList } from 'lucide-react';

interface InstructionGuideProps {
  onStart: () => void;
}

export const InstructionGuide: React.FC<InstructionGuideProps> = ({ onStart }) => {
  return (
    <div className="max-w-2xl mx-auto animate-fade-in space-y-6">
      
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-sky-400 mb-2">Multimodal Oral Health Screening System</h2>
        <p className="text-slate-400">Your task is to GUIDE the user through SAFE, HYGIENIC, and STANDARDIZED sample collection steps before analysis.</p>
      </div>

      <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl shadow-sky-900/10">
        <div className="flex items-start gap-3 mb-6 p-4 bg-slate-800/50 rounded-xl border border-slate-700">
           <Info className="w-6 h-6 text-sky-400 flex-shrink-0 mt-0.5" />
           <p className="text-slate-200 font-medium">Please follow these steps carefully for accurate results.</p>
        </div>

        <div className="space-y-8 relative">
          {/* Vertical Line */}
          <div className="absolute left-6 top-4 bottom-4 w-0.5 bg-slate-800 z-0 hidden sm:block"></div>

          {/* Step 1 */}
          <div className="relative z-10 flex flex-col sm:flex-row gap-4 sm:items-start">
            <div className="w-12 h-12 bg-slate-800 border border-slate-700 rounded-full flex items-center justify-center text-sky-400 font-bold text-lg flex-shrink-0">1</div>
            <div className="flex-1">
              <h3 className="text-lg font-bold text-slate-100 mb-2 flex items-center gap-2">
                <ClipboardList className="w-5 h-5 text-rose-400" /> Preparation
              </h3>
              <ul className="list-disc list-inside space-y-1 text-slate-300 ml-1">
                <li>Do not eat, drink, smoke, or chew gum for at least 30 minutes.</li>
                <li>Rinse your mouth once with plain water.</li>
                <li>Wait 2 minutes after rinsing.</li>
              </ul>
            </div>
          </div>

          {/* Step 2 */}
          <div className="relative z-10 flex flex-col sm:flex-row gap-4 sm:items-start">
             <div className="w-12 h-12 bg-slate-800 border border-slate-700 rounded-full flex items-center justify-center text-sky-400 font-bold text-lg flex-shrink-0">2</div>
            <div className="flex-1">
              <h3 className="text-lg font-bold text-slate-100 mb-2 flex items-center gap-2">
                 <Droplets className="w-5 h-5 text-rose-400" /> Saliva (pH) Sample
              </h3>
              <ul className="list-disc list-inside space-y-1 text-slate-300 ml-1 mb-2">
                <li>Lean over a sink.</li>
                <li>Allow saliva to naturally collect in your mouth.</li>
                <li>Gently spit the saliva into the sink.</li>
                <li>Place the pH sensor or strip into the fresh saliva.</li>
                <li>Wait until the reading stabilizes.</li>
                <li>Enter or confirm the pH value shown on the screen.</li>
              </ul>
              <p className="text-xs text-sky-400/80 italic">"This helps measure how acidic or balanced your mouth environment is."</p>
            </div>
          </div>

          {/* Step 3 */}
          <div className="relative z-10 flex flex-col sm:flex-row gap-4 sm:items-start">
             <div className="w-12 h-12 bg-slate-800 border border-slate-700 rounded-full flex items-center justify-center text-sky-400 font-bold text-lg flex-shrink-0">3</div>
            <div className="flex-1">
              <h3 className="text-lg font-bold text-slate-100 mb-2 flex items-center gap-2">
                 <Wind className="w-5 h-5 text-rose-400" /> Breath / VOC Sensor
              </h3>
              <ul className="list-disc list-inside space-y-1 text-slate-300 ml-1 mb-2">
                <li>Take a normal breath through your nose.</li>
                <li>Hold your breath for 3 seconds.</li>
                <li>Exhale slowly and steadily into the VOC sensor.</li>
                <li>Do NOT blow forcefully.</li>
                <li>Keep your lips close to the sensor opening.</li>
                <li>Stop when the device confirms measurement.</li>
              </ul>
              <p className="text-xs text-sky-400/80 italic">"This checks gases released by oral bacteria and metabolism."</p>
            </div>
          </div>

           {/* Step 4 */}
           <div className="relative z-10 flex flex-col sm:flex-row gap-4 sm:items-start">
             <div className="w-12 h-12 bg-slate-800 border border-slate-700 rounded-full flex items-center justify-center text-sky-400 font-bold text-lg flex-shrink-0">4</div>
            <div className="flex-1">
              <h3 className="text-lg font-bold text-slate-100 mb-2 flex items-center gap-2">
                 <Camera className="w-5 h-5 text-rose-400" /> Tongue Photo Capture
              </h3>
              <ul className="list-disc list-inside space-y-1 text-slate-300 ml-1">
                <li>Stand in good lighting.</li>
                <li>Open your mouth and gently stick out your tongue.</li>
                <li>Keep your tongue relaxed and still.</li>
                <li>Make sure the entire tongue is visible.</li>
                <li>Capture the photo when guided.</li>
              </ul>
            </div>
          </div>

           {/* Step 5 */}
           <div className="relative z-10 flex flex-col sm:flex-row gap-4 sm:items-start">
             <div className="w-12 h-12 bg-slate-800 border border-slate-700 rounded-full flex items-center justify-center text-sky-400 font-bold text-lg flex-shrink-0">5</div>
            <div className="flex-1">
              <h3 className="text-lg font-bold text-slate-100 mb-2 flex items-center gap-2">
                 <CheckSquare className="w-5 h-5 text-rose-400" /> Final Check
              </h3>
              <ul className="list-disc list-inside space-y-1 text-slate-300 ml-1">
                <li>Make sure all readings are recorded.</li>
                <li>Clean the sensor area if required.</li>
                <li>Tap "Analyze Results" to continue.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <div className="text-center pt-4">
        <button
          onClick={onStart}
          className="w-full sm:w-auto px-8 py-4 bg-sky-500 hover:bg-sky-400 text-white rounded-xl font-bold text-lg transition-all shadow-lg shadow-sky-500/20 hover:shadow-sky-400/30 flex items-center justify-center gap-2 mx-auto"
        >
          Start Screening Process <ArrowRight className="w-5 h-5" />
        </button>
        <p className="mt-6 text-xs text-slate-500">
          This system is for awareness and screening only.<br/>
          It does not replace professional medical advice.
        </p>
      </div>
    </div>
  );
};
