import React, { useState } from 'react';
import { AssessmentData, VOC_OPTIONS } from '../types';
import { Thermometer, Wind, Camera, Bluetooth, RefreshCw, Check, Loader2 } from 'lucide-react';

interface InputFormProps {
  data: AssessmentData;
  onChange: (newData: Partial<AssessmentData>) => void;
  onNext: () => void;
}

export const InputForm: React.FC<InputFormProps> = ({ data, onChange, onNext }) => {
  const [isScanning, setIsScanning] = useState(false);
  const [scanComplete, setScanComplete] = useState(false);

  // Simulate connecting to an external sensor and fetching data
  const handleScanSensors = () => {
    setIsScanning(true);
    
    // Simulate network/bluetooth delay
    setTimeout(() => {
      // Generate realistic random values for the demo
      // pH typically between 5.5 and 8.0
      const randomPh = (Math.random() * (8.0 - 5.5) + 5.5).toFixed(1);
      
      // Random VOC level
      const vocLevels = ['Normal', 'Moderate', 'High'];
      const randomVoc = vocLevels[Math.floor(Math.random() * vocLevels.length)];

      onChange({
        phLevel: randomPh,
        vocLevel: randomVoc
      });

      setIsScanning(false);
      setScanComplete(true);
    }, 2500);
  };

  const isFormValid = data.phLevel !== '' && data.vocLevel !== '';

  return (
    <div className="space-y-6 animate-fade-in">
      
      {/* Sensor Connection Card */}
      <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 shadow-xl shadow-sky-900/10 text-center">
        {!scanComplete ? (
          <div className="py-8">
            <div className="w-20 h-20 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-6 relative border border-slate-700">
              {isScanning ? (
                <Loader2 className="w-10 h-10 text-sky-400 animate-spin" />
              ) : (
                <Bluetooth className="w-10 h-10 text-sky-400" />
              )}
              {isScanning && (
                <div className="absolute inset-0 rounded-full border-4 border-sky-500/30 border-t-sky-400 animate-spin"></div>
              )}
            </div>
            
            <h2 className="text-2xl font-bold text-slate-100 mb-2">
              {isScanning ? "Syncing with Sensors..." : "Connect Device"}
            </h2>
            <p className="text-slate-400 mb-8 max-w-xs mx-auto">
              {isScanning 
                ? "Reading pH and VOC data from your connected oral health device." 
                : "Ensure your external sensor is turned on and ready to pair."}
            </p>

            <button
              onClick={handleScanSensors}
              disabled={isScanning}
              className={`px-8 py-4 rounded-2xl font-bold text-lg transition-all shadow-lg transform active:scale-95 ${
                isScanning 
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                  : 'bg-sky-500 hover:bg-sky-400 text-white shadow-sky-900/20'
              }`}
            >
              {isScanning ? 'Scanning...' : 'Start Sensor Scan'}
            </button>
          </div>
        ) : (
          <div className="animate-fade-in">
             <div className="w-16 h-16 bg-emerald-900/30 border border-emerald-800 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="w-8 h-8 text-emerald-400" />
             </div>
             <h2 className="text-xl font-bold text-slate-100 mb-6">Data Received</h2>
             
             <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                {/* Result Cards */}
                <div className="p-4 bg-slate-800/50 rounded-2xl border border-slate-700 flex flex-col items-center">
                   <div className="flex items-center gap-2 mb-2 text-rose-400">
                     <Thermometer className="w-5 h-5" />
                     <span className="font-semibold text-sm uppercase tracking-wide">Salivary pH</span>
                   </div>
                   <span className="text-3xl font-bold text-slate-100">{data.phLevel}</span>
                </div>

                <div className="p-4 bg-slate-800/50 rounded-2xl border border-slate-700 flex flex-col items-center">
                   <div className="flex items-center gap-2 mb-2 text-rose-400">
                     <Wind className="w-5 h-5" />
                     <span className="font-semibold text-sm uppercase tracking-wide">VOC Level</span>
                   </div>
                   <span className="text-xl font-bold text-slate-100 mt-1.5">
                     {VOC_OPTIONS.find(v => v.value === data.vocLevel)?.label || data.vocLevel}
                   </span>
                </div>
             </div>

             <div className="flex gap-3">
               <button 
                 onClick={handleScanSensors}
                 className="flex-1 py-3 px-4 bg-transparent border-2 border-slate-700 text-slate-400 font-semibold rounded-xl hover:bg-slate-800 hover:text-slate-200 transition-colors"
               >
                 Re-scan
               </button>
               <button
                  onClick={onNext}
                  disabled={!isFormValid}
                  className="flex-[2] py-3 px-4 bg-sky-500 text-white font-bold rounded-xl hover:bg-sky-400 transition-all flex items-center justify-center gap-2 shadow-lg shadow-sky-900/20"
                >
                  <Camera className="w-5 h-5" />
                  Next: Tongue Scan
                </button>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};
