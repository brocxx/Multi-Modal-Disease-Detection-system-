import React from 'react';
import { Activity, Sparkles } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="bg-slate-950/80 backdrop-blur-md border-b border-slate-800 sticky top-0 z-50">
      <div className="max-w-3xl mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-sky-900/30 p-2.5 rounded-2xl shadow-sm border border-sky-800/50">
            <Activity className="w-6 h-6 text-sky-400" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-100 leading-tight tracking-tight">OralHealth Guard</h1>
            <p className="text-xs text-rose-400 font-medium tracking-wide">Smart AI Screening</p>
          </div>
        </div>
        <div className="hidden sm:flex items-center gap-1.5 text-sky-300 bg-sky-950/50 px-4 py-1.5 rounded-full text-xs font-semibold shadow-sm border border-sky-800/50">
          <Sparkles className="w-3.5 h-3.5" />
          <span>AI Powered</span>
        </div>
      </div>
    </header>
  );
};
