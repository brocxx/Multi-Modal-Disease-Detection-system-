// Logic moved to App.tsx as per standard component structure
// This file ensures the bundler finds the entry point
import './App';
