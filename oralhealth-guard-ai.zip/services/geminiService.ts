import { GoogleGenAI } from "@google/genai";
import { AssessmentData } from "../types";

const SYSTEM_INSTRUCTION = `
You are an AI health screening assistant for a "Multimodal Oral Health Risk Detection System".

IMPORTANT ROLE:
You are NOT a doctor.
You do NOT provide medical diagnosis.
You only provide risk-level assessment and preventive guidance.

INPUT INTERPRETATION RULES:

1) SALIVARY pH INTERPRETATION
- pH >= 6.5 and <= 7.5 -> SAFE
- pH 6.0 - 6.4 OR 7.6 - 8.0 -> CAUTION
- pH < 6.0 OR > 8.0 -> DANGER

2) VOC SENSOR INTERPRETATION
- Normal VOC pattern / low sulfur compounds -> SAFE
- Moderately elevated VOCs -> CAUTION
- Strong sulfur / abnormal metabolic VOCs -> DANGER

3) TONGUE IMAGE ANALYSIS
Analyze: Color, Coating, Texture.
- Healthy pink tongue with thin coating -> SAFE
- Thick white/yellow coating, mild redness -> CAUTION
- Dark patches, ulcers, heavy coating, bleeding -> DANGER

OUTPUT FORMAT (MANDATORY):
Respond ONLY in the following structured format. Do not use Markdown formatting like bolding (**), just plain text with line breaks is fine, or standard markdown headers if needed for clarity.

OVERALL HEALTH STATUS:
[SAFE / CAUTION / DANGER]

INPUT-WISE ANALYSIS:

Salivary pH:
- Status: [Status]
- Meaning: [Simple explanation]

VOC Analysis:
- Status: [Status]
- Meaning: [Simple explanation]

Tongue Image:
- Status: [Status]
- Meaning: [Simple explanation based on visual analysis]

COMBINED INTERPRETATION:
[Explain how all inputs together indicate the current oral health risk. Use simple, reassuring language.]

RECOMMENDED ACTIONS:
[Provide ONLY non-medical guidance like hygiene, diet, hydration. DO NOT prescribe medicines.]

WHEN TO SEEK PROFESSIONAL HELP:
[Mention signs requiring a dentist visit.]

IMPORTANT DISCLAIMER:
"This tool is a screening and awareness system, not a medical diagnosis. Always consult a qualified dentist or healthcare professional for confirmation and treatment."

TONE: Calm, Supportive, Non-alarming, Easy to understand.
`;

export const analyzeOralHealth = async (data: AssessmentData): Promise<string> => {
  try {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      throw new Error("API Key is missing");
    }

    const ai = new GoogleGenAI({ apiKey });

    // Prepare content parts
    const parts: any[] = [];

    // Add Image if available
    if (data.image) {
      // Remove data URL prefix if present for the API
      const base64Data = data.image.split(',')[1]; 
      parts.push({
        inlineData: {
          mimeType: 'image/jpeg',
          data: base64Data
        }
      });
    }

    // Construct the text prompt based on form data
    const textPrompt = `
      Please analyze the following oral health data:
      
      1. Salivary pH: ${data.phLevel}
      2. VOC Sensor Output: ${data.vocLevel}
      
      Perform the analysis based on the provided image and data points according to your system instructions.
    `;

    parts.push({ text: textPrompt });

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts },
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.4, // Lower temperature for more consistent rule adherence
      }
    });

    return response.text || "Unable to generate analysis. Please try again.";

  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw error;
  }
};
