import React, { useState, useCallback } from 'react';
import { createRoot } from 'react-dom/client';
import { Header } from './components/Header';
import { InputForm } from './components/InputForm';
import { CameraCapture } from './components/CameraCapture';
import { ReportView } from './components/ReportView';
import { InstructionGuide } from './components/InstructionGuide';
import { AssessmentData, AppState } from './types';
import { analyzeOralHealth } from './services/geminiService';
import { ChevronLeft, Sparkles } from 'lucide-react';

const App: React.FC = () => {
  // Start with GUIDE state
  const [appState, setAppState] = useState<AppState>(AppState.GUIDE);
  const [data, setData] = useState<AssessmentData>({
    phLevel: '',
    vocLevel: '',
    image: null,
  });
  const [analysisResult, setAnalysisResult] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');

  const handleDataChange = (newData: Partial<AssessmentData>) => {
    setData(prev => ({ ...prev, ...newData }));
  };

  const handleCameraCapture = useCallback((base64: string) => {
    setData(prev => ({ ...prev, image: base64 }));
    setAppState(AppState.ANALYZING);
    runAnalysis({ ...data, image: base64 });
  }, [data]);

  const runAnalysis = async (finalData: AssessmentData) => {
    try {
      const result = await analyzeOralHealth(finalData);
      setAnalysisResult(result);
      setAppState(AppState.RESULT);
    } catch (err) {
      console.error(err);
      setErrorMsg("Failed to analyze data. Please check your internet connection or API key.");
      setAppState(AppState.ERROR);
    }
  };

  const resetApp = () => {
    setData({
      phLevel: '',
      vocLevel: '',
      image: null,
    });
    setAnalysisResult('');
    // Go back to GUIDE or INPUT? Usually after first time, INPUT is fine, 
    // but safety-first might imply seeing instructions again. 
    // Let's go to GUIDE to encourage protocol following.
    setAppState(AppState.GUIDE);
    setErrorMsg('');
  };

  const renderContent = () => {
    switch (appState) {
      case AppState.GUIDE:
        return <InstructionGuide onStart={() => setAppState(AppState.INPUT)} />;
        
      case AppState.INPUT:
        return (
          <div className="max-w-xl mx-auto">
             <div className="mb-8 text-center">
               <div className="inline-block p-3 bg-slate-800/50 rounded-full mb-4 border border-slate-700">
                 <Sparkles className="w-6 h-6 text-sky-400" />
               </div>
               <h2 className="text-2xl font-bold text-slate-100 mb-2">Sensor Connection</h2>
               <p className="text-slate-400 max-w-xs mx-auto">Sync your device to retrieve pH and VOC biomarkers automatically.</p>
             </div>
             <InputForm 
                data={data} 
                onChange={handleDataChange} 
                onNext={() => setAppState(AppState.CAMERA)} 
             />
          </div>
        );
      case AppState.CAMERA:
        return (
          <div className="max-w-xl mx-auto">
             <div className="mb-6 flex items-center gap-2">
                <button 
                  onClick={() => setAppState(AppState.INPUT)}
                  className="p-2 hover:bg-slate-800 rounded-full text-slate-400 transition-colors"
                >
                  <ChevronLeft />
                </button>
               <div>
                  <h2 className="text-2xl font-bold text-slate-100">Visual Analysis</h2>
                  <p className="text-slate-400 text-sm">Upload or capture a photo of your tongue.</p>
               </div>
             </div>
            <CameraCapture 
              onCapture={handleCameraCapture} 
              onCancel={() => setAppState(AppState.INPUT)} 
            />
          </div>
        );
      case AppState.ANALYZING:
        return (
          <div className="flex flex-col items-center justify-center min-h-[50vh] animate-fade-in text-center px-4">
            <div className="relative mb-8">
              <div className="w-24 h-24 border-4 border-slate-800 border-t-sky-500 rounded-full animate-spin"></div>
              <Sparkles className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-rose-400 w-8 h-8 animate-pulse" />
            </div>
            <h3 className="text-xl font-bold text-slate-100 mb-2">Processing Biomarkers</h3>
            <p className="text-slate-400 max-w-sm mx-auto leading-relaxed">
              Our AI is combining your sensor data with the visual scan to generate a health risk assessment.
            </p>
          </div>
        );
      case AppState.RESULT:
        return (
          <div className="max-w-2xl mx-auto">
            <ReportView result={analysisResult} onReset={resetApp} />
          </div>
        );
      case AppState.ERROR:
        return (
          <div className="max-w-md mx-auto text-center pt-12">
            <div className="bg-rose-950/30 p-8 rounded-3xl border border-rose-900/50 shadow-sm">
              <h3 className="text-rose-400 font-bold text-lg mb-2">Analysis Error</h3>
              <p className="text-rose-300 mb-8">{errorMsg}</p>
              <button 
                onClick={resetApp}
                className="bg-slate-900 border border-rose-900 text-rose-400 px-8 py-3 rounded-2xl font-semibold hover:bg-rose-900/20 transition-colors shadow-sm"
              >
                Try Again
              </button>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 pb-12 font-sans selection:bg-sky-900 selection:text-sky-200">
      <Header />
      <main className="container mx-auto px-4 py-8">
        {renderContent()}
      </main>
    </div>
  );
};

const rootElement = document.getElementById('root');
if (!rootElement) throw new Error('Failed to find the root element');
const root = createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
